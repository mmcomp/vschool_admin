-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 26, 2020 at 12:51 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vschool`
--

-- --------------------------------------------------------

--
-- Table structure for table `chapters`
--

CREATE TABLE `chapters` (
  `id` int(11) NOT NULL,
  `courses_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` int(11) NOT NULL DEFAULT '0' COMMENT 'icon code',
  `description` text COLLATE utf8_unicode_ci,
  `chapter_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`id`, `courses_id`, `name`, `icon`, `description`, `chapter_order`) VALUES
(1, 1, 'فیزیک مقدماتی', 0, NULL, 0),
(2, 1, 'فیزیک پیشرفته', 0, NULL, 1),
(4, 4, 'فصل اول- بیوآنتی', 0, NULL, 0),
(5, 2, 'شیمی ۱', 0, NULL, 0),
(6, 2, 'شیمی ۲', 0, NULL, 1),
(7, 1, 'فیزیک هسته ای', 0, NULL, 2),
(8, 1, 'فیزیک ۴', 0, NULL, 4),
(9, 1, 'فیزیک ۵', 0, '۵', 3);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provinces_id` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `provinces_id`, `created_at`, `updated_at`) VALUES
(1, 'تهران', 1, '2019-08-28 00:00:00', '2019-08-28 00:00:00'),
(2, 'مشهد', 2, '2019-08-28 00:00:00', '2019-08-28 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `teacher_id` int(11) NOT NULL DEFAULT '0',
  `education_level` int(11) NOT NULL DEFAULT '7',
  `duel_time` int(11) NOT NULL DEFAULT '100',
  `published` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `name`, `description`, `teacher_id`, `education_level`, `duel_time`, `published`) VALUES
(1, 'فیزیک', NULL, 4, 7, 101, 0),
(2, 'شیمی', NULL, 6, 7, 100, 0),
(4, 'شیمی عالی', NULL, 0, 7, 100, 0);

-- --------------------------------------------------------

--
-- Table structure for table `duels`
--

CREATE TABLE `duels` (
  `id` int(11) NOT NULL,
  `education_level` int(11) NOT NULL DEFAULT '7',
  `starter_users_id` int(11) NOT NULL DEFAULT '0',
  `opponent_users_id` int(11) NOT NULL DEFAULT '0',
  `details` json DEFAULT NULL,
  `user_turn` enum('starter','opponent') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'starter',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `duels`
--

INSERT INTO `duels` (`id`, `education_level`, `starter_users_id`, `opponent_users_id`, `details`, `user_turn`, `created_at`, `updated_at`) VALUES
(1, 7, 4, 3, NULL, 'opponent', '2019-09-23 12:36:06', '2019-09-23 14:33:03');

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE `lessons` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `chapters_id` int(11) NOT NULL,
  `lesson_order` int(11) NOT NULL DEFAULT '0',
  `literary_editor` tinyint(1) NOT NULL DEFAULT '0',
  `scientific_editor` tinyint(1) NOT NULL DEFAULT '0',
  `layout_page_editor` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id`, `name`, `description`, `chapters_id`, `lesson_order`, `literary_editor`, `scientific_editor`, `layout_page_editor`) VALUES
(1, 'درس اول چ۱', NULL, 1, 0, 1, 1, 1),
(2, 'درس دوم چ۱', NULL, 1, 2, 0, 0, 1),
(3, 'درس اول چ۲', NULL, 2, 0, 0, 1, 1),
(4, 'درس دوم چ ۲', NULL, 2, 1, 1, 0, 0),
(6, 'اکسیداسون', NULL, 6, 0, 0, 0, 0),
(7, 'احیا', NULL, 6, 1, 0, 0, 0),
(8, 'درس سوم', '3', 1, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `levels`
--

CREATE TABLE `levels` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `min_score` int(11) NOT NULL DEFAULT '0',
  `max_score` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `lessons_id` int(11) NOT NULL DEFAULT '0',
  `page` json DEFAULT NULL,
  `page_order` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `lessons_id`, `page`, `page_order`, `created_at`, `updated_at`) VALUES
(13, 1, '{\"data\": [{\"data\": \"test1\", \"type\": \"content\", \"deleted\": false}, {\"ext\": \"png\", \"data\": \"image_1.png\", \"type\": \"image\", \"deleted\": false}, {\"data\": \"H_2O\", \"type\": \"formula\", \"deleted\": false}, {\"data\": \"K_2O\", \"type\": \"formula\", \"deleted\": false}, {\"data\": \"note\", \"type\": \"note\", \"deleted\": false}], \"title\": \"test1\"}', 8, '2019-11-30 10:46:48', '2020-01-20 13:22:50'),
(17, 1, '{\"data\": [{\"data\": \"image_0.png\", \"type\": \"image\", \"deleted\": false}], \"title\": \"test3\"}', 12, '2019-11-30 10:52:06', '2019-11-30 10:52:06'),
(18, 7, '{\"data\": [{\"data\": \"C + O_2 \\\\rightarrow CO_2\", \"type\": \"formula\", \"deleted\": false}, {\"data\": \"سوختن یعنی افزایش انرژی\", \"type\": \"content\", \"deleted\": false}, {\"data\": \"H_20 + Ni \\\\rightarrow H_2 + NiO2\", \"type\": \"formula\", \"deleted\": false}, {\"data\": \"در فرمول بالا اتم هیدروژن H داغان است\", \"type\": \"note\", \"deleted\": false}, {\"data\": \"همانطور که در درس ... گفته شده، هیچگاه نمی تواند دو ماده زکریا رازی را نخورد\", \"type\": \"content\", \"deleted\": false}, {\"ext\": \"jpg\", \"data\": \"image_4.jpg\", \"type\": \"image\", \"deleted\": false}, {\"data\": \"سوختن یک فعالیت شیمایی است.\", \"type\": \"note\", \"deleted\": false}], \"title\": \"سوختن\"}', 0, '2019-11-30 13:17:11', '2019-12-09 13:21:44'),
(19, 7, '{\"data\": [{\"data\": \"سوختن بر خلاف ساختن است\", \"type\": \"content\", \"deleted\": false}, {\"data\": \"CO_2 \\\\rightarrow C + O_2\", \"type\": \"formula\", \"deleted\": false}, {\"data\": \"سوختن باید سوختن باشد، سوختنی که سوختن نباشد ساختن است.\", \"type\": \"note\", \"deleted\": false}, {\"data\": \"H_2O \\\\rightarrow H_2 + O\", \"type\": \"formula\", \"deleted\": false}], \"title\": \"سوختن و ساختن\"}', 0, '2019-11-30 14:08:38', '2019-11-30 14:29:57'),
(20, 7, '{\"data\": [{\"data\": \"پوختن یعنی بسوز و بساز\", \"type\": \"content\", \"deleted\": false}, {\"data\": \"وسط چین\", \"type\": \"note\", \"deleted\": false}, {\"data\": \"H_2O \\\\rightarrow H_2 + O_5\", \"type\": \"formula\", \"deleted\": false}, {\"data\": \"هیچ پوختنی بی دلیل نیست.\", \"type\": \"note\", \"deleted\": false}], \"title\": \"پوختن\"}', 0, '2019-11-30 14:48:24', '2019-11-30 15:02:26'),
(21, 7, '{\"data\": [{\"data\": \"لیلا\", \"type\": \"content\", \"deleted\": false}], \"title\": \"سپوختن\"}', 0, '2019-11-30 14:52:31', '2019-11-30 14:52:31'),
(22, 7, '{\"data\": [{\"data\": \"محلا محلا احیا محیا\", \"type\": \"content\", \"deleted\": false}, {\"data\": \"J_2 + O_2 \\\\rightarrow OJ_4\", \"type\": \"formula\", \"deleted\": false}, {\"data\": \"محیا رهرا\", \"type\": \"note\", \"deleted\": false}], \"title\": \"محیا\"}', 0, '2019-11-30 14:57:01', '2019-11-30 14:57:01'),
(23, 1, '{\"data\": [{\"data\": \"BUG1\", \"type\": \"content\", \"deleted\": false}], \"title\": \"bug\"}', 13, '2019-12-26 09:22:17', '2019-12-26 09:22:17'),
(24, 1, '{\"data\": [{\"data\": \"boog\", \"type\": \"content\", \"deleted\": false}], \"title\": \"boog\"}', 14, '2019-12-26 09:44:15', '2019-12-26 09:44:15'),
(25, 1, '{\"data\": [{\"data\": \"aaaaaaa\", \"type\": \"content\", \"deleted\": false}], \"title\": \"aaaa\"}', 15, '2019-12-26 09:51:37', '2019-12-26 09:51:37'),
(26, 1, '{\"data\": [{\"data\": \"aaaaaaa\", \"type\": \"content\", \"deleted\": false}], \"title\": \"aaaa\"}', 16, '2019-12-26 09:52:06', '2019-12-26 09:52:06'),
(30, 1, '{\"data\": [{\"data\": \"چند سوالی متن\", \"type\": \"content\", \"deleted\": false}], \"title\": \"چند سوالی\"}', 17, '2019-12-31 15:03:14', '2019-12-31 15:14:37');

-- --------------------------------------------------------

--
-- Table structure for table `provinces`
--

CREATE TABLE `provinces` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `provinces`
--

INSERT INTO `provinces` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'تهران', '2019-08-28 00:00:00', '2019-08-28 00:00:00'),
(2, 'خراسان رضوی', '2019-08-28 00:00:00', '2019-08-28 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `courses_id` int(11) NOT NULL DEFAULT '0',
  `chapters_id` int(11) NOT NULL DEFAULT '0',
  `lessons_id` int(11) NOT NULL DEFAULT '0',
  `pages_id` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `question_type` enum('choice_question','answer','fill_blank') COLLATE utf8_unicode_ci NOT NULL,
  `answer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'پاسخ درصورت سوال متنی',
  `choices` json NOT NULL,
  `score` int(11) NOT NULL DEFAULT '0',
  `literary_editor` tinyint(1) NOT NULL DEFAULT '0',
  `scientific_editor` tinyint(1) NOT NULL DEFAULT '0',
  `layout_page_editor` tinyint(1) NOT NULL DEFAULT '0',
  `solution` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `courses_id`, `chapters_id`, `lessons_id`, `pages_id`, `question`, `question_type`, `answer`, `choices`, `score`, `literary_editor`, `scientific_editor`, `layout_page_editor`, `solution`) VALUES
(1, 0, 0, 1, 7, 'سوال ۱', 'choice_question', 'aaaa', '[{\"answer\": \"یک\", \"checked\": true}, {\"answer\": \"دو\", \"checked\": true}]', 1, 1, 1, 1, NULL),
(2, 0, 0, 1, 0, 'سوال دو', 'answer', NULL, 'null', 0, 0, 0, 0, NULL),
(3, 0, 0, 1, 6, 'سوال bbb', 'answer', '*bbb,bb,b', 'null', 2, 0, 0, 0, NULL),
(4, 2, 0, 6, 8, 'بسسیبلیلبلب', 'choice_question', NULL, '[]', 0, 1, 1, 1, NULL),
(5, 1, 0, 1, 10, 'aaaaa', 'answer', 'dsfdf', '[]', 0, 0, 0, 0, NULL),
(6, 1, 0, 1, 9, NULL, 'answer', NULL, '[]', 0, 0, 0, 0, NULL),
(7, 1, 0, 1, 3, NULL, 'answer', NULL, '[]', 0, 0, 0, 0, NULL),
(8, 1, 0, 1, 11, NULL, 'answer', NULL, '[]', 0, 0, 0, 0, NULL),
(9, 2, 0, 7, 12, 'کدام فرمول زیر نشان سوختن صحیح است؟', 'choice_question', NULL, '[{\"answer\": \"4Na_{s}  + O_2_{(g)}  \\\\rightarrow  2Na_{2}O_s\", \"checked\": false}, {\"answer\": \"4Na_{s}  + O_2_{(g)}  \\\\rightarrow  2Na_{2}O_s\", \"checked\": false}, {\"answer\": \"هر دو مورد\", \"checked\": true}]', 5, 0, 0, 0, NULL),
(11, 1, 0, 1, 15, 'e', 'answer', 'q', '[]', 0, 0, 0, 0, NULL),
(12, 1, 0, 1, 16, 'a', 'answer', 'f', '[]', 0, 0, 0, 0, NULL),
(13, 1, 0, 1, 17, 'k', 'answer', 'k', '[]', 0, 0, 0, 0, NULL),
(14, 2, 0, 7, 18, 'کدام فرمول مربوط به واکنش سوختن است', 'choice_question', NULL, '[{\"answer\": \"H_2 + O_2 \\\\rightarrow H_2O\", \"checked\": false}, {\"answer\": \"C + O_2  \\\\rightarrow CO_2\", \"checked\": false}, {\"answer\": \"هر دو مورد\", \"checked\": true}]', 5, 0, 0, 0, NULL),
(15, 2, 0, 7, 19, 'تست ### دارد###', 'fill_blank', NULL, '[{\"answer\": \"عباس\", \"checked\": false}, {\"answer\": \"علی\", \"checked\": false}]', 0, 0, 0, 0, NULL),
(16, 2, 0, 7, 20, 'با پوختن ### سه واخد ### و دو واحد ### تولید می شود', 'fill_blank', NULL, '[{\"answer\": \"آب\", \"checked\": false}, {\"answer\": \"اکسیژن\", \"checked\": false}, {\"answer\": \"هیدروژن\", \"checked\": false}]', 4, 0, 0, 1, NULL),
(17, 2, 0, 7, 22, 'محیا ### ایمان ### محلا ###', 'fill_blank', NULL, '[{\"answer\": \"پوختن\", \"checked\": false}, {\"answer\": \"سوختن\", \"checked\": false}, {\"answer\": \"دوختن\", \"checked\": false}]', 3, 0, 0, 0, NULL),
(18, 4, 4, 0, 0, 'تست', 'answer', 'آ', '[]', 0, 0, 0, 0, 'ب'),
(19, 1, 0, 1, 23, 'a', 'answer', 'a', '[]', 0, 0, 0, 0, 'a'),
(20, 1, 0, 1, 24, 'b', 'answer', 'b', '[]', 0, 0, 0, 0, 'b'),
(21, 1, 0, 1, 25, 'd', 'answer', 'd', '[]', 0, 0, 0, 0, 'd'),
(22, 1, 0, 1, 26, 'd', 'answer', 'd', '[]', 0, 0, 0, 0, 'd'),
(23, 1, 0, 1, 28, 'سوال ۱', 'choice_question', NULL, '[]', 0, 0, 0, 0, 'راه ۱'),
(24, 1, 0, 1, 29, 'سوال ۱', 'choice_question', NULL, '[]', 0, 0, 0, 0, 'راه ۱'),
(25, 1, 0, 1, 29, 'سوال ۲', 'fill_blank', NULL, '[]', 0, 0, 0, 0, 'راه ۲'),
(29, 1, 0, 1, 13, 'q', 'choice_question', NULL, '[{\"answer\": \"1\", \"checked\": false}, {\"answer\": \"2\", \"checked\": false}, {\"answer\": \"3a\", \"checked\": true}]', 0, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `question_accesses`
--

CREATE TABLE `question_accesses` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `courses_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `question_accesses`
--

INSERT INTO `question_accesses` (`id`, `users_id`, `courses_id`) VALUES
(1, 6, 1),
(2, 6, 2);

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zones_id` int(11) NOT NULL DEFAULT '0',
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manager_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` enum('male','female','both') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'male',
  `school_type` enum('public','private') COLLATE utf8_unicode_ci NOT NULL,
  `cycle` enum('first','second','both') COLLATE utf8_unicode_ci NOT NULL,
  `created_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `name`, `zones_id`, `code`, `address`, `manager_name`, `gender`, `school_type`, `cycle`, `created_date`) VALUES
(2, 'سلمان فارسی', 2, '2324324234', 'ندارد', 'محمد', 'male', 'private', 'both', '1997-05-05 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 'chapter_exam_advance', '4', '2019-12-24 00:00:00', '2019-12-24 14:00:53');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `student_number` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar` int(11) DEFAULT '1',
  `score` int(11) NOT NULL DEFAULT '0',
  `gender` enum('male','female') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'male',
  `education_level` int(11) NOT NULL DEFAULT '7' COMMENT '7-12',
  `schools_id` int(11) NOT NULL DEFAULT '0',
  `is_guest` tinyint(1) NOT NULL DEFAULT '1',
  `otp` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT '1' COMMENT '0 : admin, 1 : student, 2 : teacher',
  `duel_wins` int(11) NOT NULL DEFAULT '0',
  `duel_losts` int(11) NOT NULL DEFAULT '0',
  `last_activity` datetime DEFAULT NULL,
  `push_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `password`, `remember_token`, `salt`, `mobile`, `student_number`, `avatar`, `score`, `gender`, `education_level`, `schools_id`, `is_guest`, `otp`, `group_id`, `duel_wins`, `duel_losts`, `last_activity`, `push_id`, `created_at`, `updated_at`) VALUES
(1, 'مهرداد', 'میرسمیع', 'm.mirsamie@gmail.com', '$2b$10$Z4lIXtq88FFwddug.SPXvO4Q6DlbE4zZjh/amWl8gldl7hpRKzEie', 'jcAAzVe82ztgnvtLnmsm7BRQWdndB8mTyxhbjaD5ZvYnolcCPyWTrEG96qEt', '$2b$10$Z4lIXtq88FFwddug.SPXvO', NULL, NULL, 1, 0, 'male', 7, 0, 0, NULL, 0, 0, 0, NULL, NULL, NULL, NULL),
(2, NULL, 'guest_14', 'guest_14', '$2b$10$VDek.6b4.fWCkiBt1.tKiON9dHXvuElr2gKXdGn37F6YeMMALySt6', NULL, '$2b$10$VDek.6b4.fWCkiBt1.tKiO', NULL, NULL, 1, 0, 'male', 7, 0, 1, NULL, 1, 0, 0, NULL, NULL, NULL, NULL),
(3, 'علی', 'محمدی', 'mad_moon_lover1@yahoo.com', '$2b$10$d20Lxi4kMeflJSMGAhvjMuj6SB0/xRgc4nK0SWVpwFJp2s4bqmuEe', NULL, '$2b$10$d20Lxi4kMeflJSMGAhvjMu', '09120172768', 'ا۱۳۳۴د۴۵۶۵', 1, 0, 'male', 7, 1, 0, '4742', 1, 0, 0, '2020-01-05 15:12:25', 'kj45h34lkjkl3j45434hb5345lkj', '2019-08-14 09:53:40', '2020-01-05 15:12:25'),
(4, 'رضا', 'محمدی5', 'reza25@yahoo.com', '$2b$10$8IHgNjHFiIY/J67CYVHihudhSX4RGQK1hErjNqElVqAjjM/jhxjVm', 'jig6ZulDuwTLCVJYIVlDSHdvsBhfglP4wOj2jBjVl0bjNszDqOnOOZucIbcN', '$2b$10$8IHgNjHFiIY/J67CYVHihu', '09155193104', 'ا۱۳۳۴د۴۵۶۵', 1, 0, 'male', 7, 1, 0, '8237', 2, 0, 0, NULL, NULL, '2019-08-14 12:07:13', '2019-09-01 13:07:46'),
(6, 'عباس', 'میرسکیع', 'mad_moon_lover@yahoo.com', '$2y$10$5OuFiPqH7X5eMG9w2RMmBuRLGzmAq8Ie430GG5mWldhcdi1y611X.', 'ZOyB52eEbpBm6ToaMSEd01zoCUNVQbRxaARqQhlHq98yWEvrR8FggymP4RyI', NULL, NULL, NULL, 1, 0, 'male', 7, 0, 1, NULL, 2, 0, 0, NULL, NULL, '2019-08-28 10:20:20', '2019-08-28 10:20:20'),
(7, NULL, 'guest_1567326566645', 'guest_1567326566645', '$2b$10$Xxcr9iIC2.C.OoD.DYuTkupX2wMA62UhB6OWK04q08fmsIykZhdiq', NULL, '$2b$10$Xxcr9iIC2.C.OoD.DYuTku', NULL, NULL, 1, 0, 'male', 7, 0, 1, NULL, 1, 0, 0, NULL, NULL, '2019-09-01 12:59:27', '2019-09-01 12:59:27'),
(8, NULL, 'guest_1567330149379', 'guest_1567330149379', '$2b$10$RLzLl0QCe03U5mQwKukAlO34gLbSc.YVthX9H7w9BR2bcvOchwcjy', NULL, '$2b$10$RLzLl0QCe03U5mQwKukAlO', NULL, NULL, 1, 0, 'male', 7, 0, 1, NULL, 1, 0, 0, NULL, NULL, '2019-09-01 13:59:10', '2019-09-01 13:59:10'),
(9, NULL, 'guest_1575100217456', 'guest_1575100217456', '$2b$10$zGWWU5d1xraoYH4jrfXOCuH7KFoL0KhcY6/4YmGFLhI6bKmuwShSa', NULL, '$2b$10$zGWWU5d1xraoYH4jrfXOCu', NULL, NULL, 1, 0, 'male', 7, 0, 1, NULL, 1, 0, 0, '2019-11-30 14:20:05', NULL, '2019-11-30 11:20:18', '2019-11-30 14:20:05'),
(10, NULL, 'guest_1575111667978', 'guest_1575111667978', '$2b$10$80qdo5KlhHqlZ5robwgv..wKf1tzIopFKHnl/mg8GKaB32u..YIi.', NULL, '$2b$10$80qdo5KlhHqlZ5robwgv..', NULL, NULL, 1, 0, 'male', 7, 0, 1, NULL, 1, 0, 0, '2019-11-30 15:14:37', NULL, '2019-11-30 14:31:08', '2019-11-30 15:14:37');

-- --------------------------------------------------------

--
-- Table structure for table `users_chapters`
--

CREATE TABLE `users_chapters` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `chapters_id` int(11) NOT NULL DEFAULT '0',
  `score` int(11) NOT NULL DEFAULT '0',
  `stars` int(11) NOT NULL DEFAULT '0',
  `quiz_status` enum('didnot','failed','passed','quiz') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'didnot',
  `created_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users_chapters`
--

INSERT INTO `users_chapters` (`id`, `users_id`, `chapters_id`, `score`, `stars`, `quiz_status`, `created_date`) VALUES
(1, 3, 1, 10, 4, 'passed', '2019-12-16 00:00:00'),
(2, 3, 2, 0, 0, 'quiz', '2019-12-17 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users_courses`
--

CREATE TABLE `users_courses` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `courses_id` int(11) NOT NULL DEFAULT '0',
  `quiz_status` enum('didnot','failed','passed','quiz') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'didnot',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users_lessons`
--

CREATE TABLE `users_lessons` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `lessons_id` int(11) NOT NULL DEFAULT '0',
  `quiz_status` enum('didnot','failed','passed','quiz') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'didnot',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users_lessons`
--

INSERT INTO `users_lessons` (`id`, `users_id`, `lessons_id`, `quiz_status`, `created_at`, `updated_at`) VALUES
(3, 3, 4, 'didnot', '2019-09-07 14:11:50', '2019-09-07 14:11:50'),
(4, 3, 1, 'quiz', '2019-12-10 00:00:00', '2019-12-11 00:00:00'),
(5, 3, 8, 'passed', '2019-12-15 00:00:00', '2019-12-16 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users_pages`
--

CREATE TABLE `users_pages` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `pages_id` int(11) NOT NULL DEFAULT '0',
  `quiz_status` enum('didnot','failed','passed','quiz') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'didnot',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users_questions`
--

CREATE TABLE `users_questions` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `questions_id` int(11) NOT NULL DEFAULT '0',
  `status` enum('correct','incorrect') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'incorrect',
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `zones`
--

CREATE TABLE `zones` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cities_id` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `zones`
--

INSERT INTO `zones` (`id`, `name`, `cities_id`, `created_at`, `updated_at`) VALUES
(1, 'ناحیه یک', 2, '2019-08-28 00:00:00', '2019-08-28 00:00:00'),
(2, 'ناحیه دو', 2, '2019-08-28 00:00:00', '2019-08-28 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chapters`
--
ALTER TABLE `chapters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `duels`
--
ALTER TABLE `duels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lessons`
--
ALTER TABLE `lessons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `levels`
--
ALTER TABLE `levels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provinces`
--
ALTER TABLE `provinces`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question_accesses`
--
ALTER TABLE `question_accesses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_chapters`
--
ALTER TABLE `users_chapters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_courses`
--
ALTER TABLE `users_courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_lessons`
--
ALTER TABLE `users_lessons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_pages`
--
ALTER TABLE `users_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_questions`
--
ALTER TABLE `users_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zones`
--
ALTER TABLE `zones`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chapters`
--
ALTER TABLE `chapters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `duels`
--
ALTER TABLE `duels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lessons`
--
ALTER TABLE `lessons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `levels`
--
ALTER TABLE `levels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `provinces`
--
ALTER TABLE `provinces`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `question_accesses`
--
ALTER TABLE `question_accesses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users_chapters`
--
ALTER TABLE `users_chapters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users_courses`
--
ALTER TABLE `users_courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_lessons`
--
ALTER TABLE `users_lessons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users_pages`
--
ALTER TABLE `users_pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_questions`
--
ALTER TABLE `users_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `zones`
--
ALTER TABLE `zones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
